package custommas.ui;

public interface IInputCallback {
	void inputReceived(String input);
}
