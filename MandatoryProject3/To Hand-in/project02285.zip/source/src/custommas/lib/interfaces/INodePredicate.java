package custommas.lib.interfaces;

import custommas.lib.Node;

//Andreas (s092638)

public interface INodePredicate {
	boolean evaluate(Node node, int comparableValue);
}
